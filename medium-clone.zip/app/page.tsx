import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4 md:px-6">
          <Link href="/" className="text-2xl font-serif font-bold">
            Pencraft
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
              Our story
            </Link>
            <Link href="/membership" className="text-sm text-muted-foreground hover:text-foreground">
              Membership
            </Link>
            <Link href="/write" className="text-sm text-muted-foreground hover:text-foreground">
              Write
            </Link>
            <Link href="/signin" className="text-sm text-muted-foreground hover:text-foreground">
              Sign in
            </Link>
            <Button asChild className="rounded-full bg-black text-white hover:bg-black/90">
              <Link href="/get-started">Get started</Link>
            </Button>
          </nav>
          <Button variant="ghost" size="icon" className="md:hidden">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <section className="py-20 md:py-32 relative overflow-hidden">
          <div className="container mx-auto px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <h1 className="text-5xl md:text-7xl font-serif font-bold leading-tight">Human stories & ideas</h1>
                <p className="text-xl text-muted-foreground">A place to read, write, and deepen your understanding</p>
                <Button asChild className="rounded-full bg-black text-white hover:bg-black/90 px-8 py-6 h-auto text-lg">
                  <Link href="/start-reading">Start reading</Link>
                </Button>
              </div>
              <div className="relative hidden md:block">
                <div className="absolute top-0 right-0 w-80 h-80 bg-green-500 rounded-full opacity-80 blur-2xl"></div>
                <div className="absolute bottom-20 right-20 w-40 h-40 bg-green-400 rounded-full opacity-70 blur-xl"></div>
                <div className="relative z-10">
                  <svg viewBox="0 0 200 200" className="w-64 h-64 text-green-500 mx-auto" fill="currentColor">
                    <path
                      d="M47.1,-57.8C59.5,-47.8,67.6,-31.5,71.5,-14.2C75.4,3.1,75.2,21.5,67.1,35.1C59,48.7,43,57.5,26.5,63.2C10,68.9,-7,71.5,-23.8,67.7C-40.5,63.9,-57,53.7,-65.3,38.9C-73.5,24.1,-73.5,4.6,-69.2,-13.1C-65,-30.8,-56.5,-46.7,-43.7,-56.6C-30.9,-66.5,-15.5,-70.3,0.9,-71.4C17.2,-72.5,34.7,-67.8,47.1,-57.8Z"
                      transform="translate(100 100)"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl font-serif font-bold mb-8">Trending on Pencraft</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <article key={i} className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-full bg-gray-200 overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=32&width=32"
                        alt="Author"
                        width={32}
                        height={32}
                        className="object-cover"
                      />
                    </div>
                    <span className="text-sm font-medium">Author Name</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2 line-clamp-2">
                    <Link href={`/post/${i}`} className="hover:underline">
                      This is a sample blog post title that might span multiple lines
                    </Link>
                  </h3>
                  <p className="text-muted-foreground line-clamp-3 mb-4">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
                  </p>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>Apr 11 · 5 min read</span>
                    <button className="text-gray-500 hover:text-gray-700">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-5 w-5"
                      >
                        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                      </svg>
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-8">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Pencraft. All rights reserved.
            </div>
            <nav className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              <Link href="/help" className="hover:underline">
                Help
              </Link>
              <Link href="/status" className="hover:underline">
                Status
              </Link>
              <Link href="/about" className="hover:underline">
                About
              </Link>
              <Link href="/careers" className="hover:underline">
                Careers
              </Link>
              <Link href="/blog" className="hover:underline">
                Blog
              </Link>
              <Link href="/privacy" className="hover:underline">
                Privacy
              </Link>
              <Link href="/terms" className="hover:underline">
                Terms
              </Link>
              <Link href="/text-to-speech" className="hover:underline">
                Text to speech
              </Link>
            </nav>
          </div>
        </div>
      </footer>
    </div>
  )
}
