import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function PostPage({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b">
        <div className="container mx-auto flex items-center justify-between py-4 px-4 md:px-6">
          <Link href="/" className="text-2xl font-serif font-bold">
            Pencraft
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
              Our story
            </Link>
            <Link href="/membership" className="text-sm text-muted-foreground hover:text-foreground">
              Membership
            </Link>
            <Link href="/write" className="text-sm text-muted-foreground hover:text-foreground">
              Write
            </Link>
            <Link href="/signin" className="text-sm text-muted-foreground hover:text-foreground">
              Sign in
            </Link>
            <Button asChild className="rounded-full bg-black text-white hover:bg-black/90">
              <Link href="/get-started">Get started</Link>
            </Button>
          </nav>
          <Button variant="ghost" size="icon" className="md:hidden">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <article className="container mx-auto px-4 md:px-6 py-10 max-w-3xl">
          <div className="mb-8">
            <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">
              This is a sample blog post title that might span multiple lines
            </h1>
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="Author"
                    width={40}
                    height={40}
                    className="object-cover"
                  />
                </div>
                <div>
                  <div className="font-medium">Author Name</div>
                  <div className="text-sm text-muted-foreground">Apr 11 · 5 min read</div>
                </div>
              </div>
              <div className="ml-auto flex gap-2">
                <Button variant="ghost" size="icon" className="rounded-full">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" />
                    <polyline points="16 6 12 2 8 6" />
                    <line x1="12" x2="12" y1="2" y2="15" />
                  </svg>
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5"
                  >
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                  </svg>
                </Button>
              </div>
            </div>
            <div className="w-full h-[400px] bg-gray-100 rounded-lg overflow-hidden mb-8">
              <Image
                src="/placeholder.svg?height=800&width=1200"
                alt="Blog post cover"
                width={1200}
                height={800}
                className="object-cover w-full h-full"
              />
            </div>
          </div>
          <div className="prose prose-lg max-w-none">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et
              dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex
              ea commodo consequat.
            </p>
            <p>
              Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
              Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
              laborum.
            </p>
            <h2>This is a section heading</h2>
            <p>
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam
              rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt
              explicabo.
            </p>
            <blockquote>
              <p>
                This is a blockquote that might contain an important excerpt from the article or a quote from someone
                mentioned in the article.
              </p>
            </blockquote>
            <p>
              Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni
              dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor
              sit amet, consectetur, adipisci velit.
            </p>
            <h2>Another section heading</h2>
            <p>
              At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti
              atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique
              sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.
            </p>
            <p>
              Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est
              eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas
              assumenda est, omnis dolor repellendus.
            </p>
          </div>
          <div className="mt-10 pt-8 border-t">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden">
                <Image
                  src="/placeholder.svg?height=48&width=48"
                  alt="Author"
                  width={48}
                  height={48}
                  className="object-cover"
                />
              </div>
              <div>
                <div className="font-medium">Written by Author Name</div>
                <div className="text-sm text-muted-foreground">
                  Author bio goes here. This is a short description about the author.
                </div>
              </div>
            </div>
            <Button className="rounded-full">Follow</Button>
          </div>
        </article>
      </main>
      <footer className="border-t py-8">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Pencraft. All rights reserved.
            </div>
            <nav className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              <Link href="/help" className="hover:underline">
                Help
              </Link>
              <Link href="/status" className="hover:underline">
                Status
              </Link>
              <Link href="/about" className="hover:underline">
                About
              </Link>
              <Link href="/careers" className="hover:underline">
                Careers
              </Link>
              <Link href="/blog" className="hover:underline">
                Blog
              </Link>
              <Link href="/privacy" className="hover:underline">
                Privacy
              </Link>
              <Link href="/terms" className="hover:underline">
                Terms
              </Link>
              <Link href="/text-to-speech" className="hover:underline">
                Text to speech
              </Link>
            </nav>
          </div>
        </div>
      </footer>
    </div>
  )
}
